clear; close all; clc;
PM25=xlsread("Vehicle_RESPdeaths.xlsx","I2:I1355");
A = 0.9780; B = [0.0002 4.5483];
Vehicle = xlsread("Vehicle_RESPdeaths.xlsx","D2:D1355");
Deaths =  round([mean(xlsread("Vehicle_RESPdeaths.xlsx","M2:M1354"));xlsread("Vehicle_RESPdeaths.xlsx","M2:M1354")]/100);
A = 0.2992; B = [9.6962 10.8393];
R = var(Deaths)^0.5;
q=0.05;
p=zeros(1,1354);
kg=zeros(1,1354);
xk=zeros(1354*2,1);
xk(1)=Deaths(1);
p(1)=var(Deaths)^0.5;
avr=[Vehicle(size(Vehicle,1)-1353:size(Vehicle,1),:)]/(365*50)
for i=1:1354
   avr=[avr;(mean(avr(size(avr,1)-1353:size(avr,1),:))+sqrt(var(avr(size(avr,1)-1353:size(avr,1),:)))*0.5)*1.1];
end
Vehicle=round(avr);
ar=[PM25(size(PM25,1)-1353:size(PM25,1),:)]
for i=1:1354
   ar=[ar;(mean(ar(size(ar,1)-1353:size(ar,1),:))+sqrt(var(ar(size(ar,1)-1353:size(ar,1),:)))*0.5)*1.1];
end
PM25=ar;
% In loop 

for i=1:1354
zk = Deaths(i);
kg(i)=p(i)*A/(A*p(i)*A'+R);
xk(i)=xk(i)+kg(i)*(zk-xk(i));
p(i)=(1-kg(i))*p(i);
xk(i+1)=A*xk(i)+B*[Vehicle(i);PM25(i)];
p(i+1)=A*p(i)*A'+q;
buff_zk(i) = zk(1);
end

for i=1354:1354*2
zk = xk(i);
kg(i)=p(i)*A/(A*p(i)*A'+R);
xk(i)=xk(i)+kg(i)*(zk-xk(i));
p(i)=(1-kg(i))*p(i);
xk(i+1)=A*xk(i)+B*[Vehicle(i);PM25(i)];
p(i+1)=A*p(i)*A'+q;
end
xk=round(xk)
figure(1)
hold on
plot(buff_zk,'g' ,'linewidth',2 )
plot(xk,'r' ,'linewidth',2 )
title('Number of deaths and chronic diseases due to respiratory diseases and prediction using Kalman Filter')
xlabel('time in days'); ylabel('value')
legend('Original Value','Estimation using kalman filter')