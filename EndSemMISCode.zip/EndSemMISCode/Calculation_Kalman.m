PM25=xlsread("Vehicle_RESPdeaths.xlsx","I2:I1355");
Vehicle = xlsread("Vehicle_RESPdeaths.xlsx","D2:D1355");
Deaths =  xlsread("Vehicle_RESPdeaths.xlsx","E2:E1355");
temp=[0;xlsread("Vehicle_RESPdeaths.xlsx","E2:E1354")];
Vehcileex=mean(Vehicle)+var(Vehicle).*rand(size(Vehicle));
A = [temp Vehicle PM25];
pinv(A)*Deaths
plot(Deaths,'r' ,'linewidth',2 )
plot(temp,'g' ,'linewidth',2 )
title('Number of deaths due to respiratory diseases and prediction using Kalman Filter')
xlabel('time in days'); ylabel('value')
legend('Kalman Filter Signal','Number of Deaths due to Respiratory diseases')
