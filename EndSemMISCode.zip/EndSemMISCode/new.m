clear all;close all;clc;
PM25=xlsread("Vehicle_RESPdeaths.xlsx","F2:F1355");
Vehicle = round(xlsread("Vehicle_RESPdeaths.xlsx","D2:D1355")/365/50);
Deaths =  round(xlsread("Vehicle_RESPdeaths.xlsx","M2:M1355")/50);
temp=round([mean(xlsread("Vehicle_RESPdeaths.xlsx","M2:M1354"));xlsread("Vehicle_RESPdeaths.xlsx","M2:M1354")]/50);
A = [temp Vehicle PM25];
pinv(A)*Deaths